🚀 LinkedIn Network Builder - Complete Setup

QUICK START:
1. Open Command Prompt or PowerShell in this folder
2. Run: linkedin-network-builder.exe --install-browsers
   (This installs browser components - only needed once)
3. Run: linkedin-network-builder.exe
   (This starts the main application)
4. The system will automatically:
   - Start the LinkedIn Network Builder API
   - Create a secure ngrok tunnel
   - Ask if you want ChatGPT integration
5. Choose 'y' for ChatGPT setup (browser will open)
6. Log in to ChatGPT when prompted
7. Your GPT will be ready to use immediately!

ALTERNATIVE ONE-COMMAND START:
Just run: linkedin-network-builder.exe
(It will auto-install browsers if needed, but may take longer)

WHAT'S INCLUDED:
- linkedin-network-builder.exe: Complete application with integrated setup
- gpt_manager.py: Automatic GPT configuration
- ngrok.exe: Secure tunnel software
- GPT/instructions.txt: GPT instructions template
- GPT/openapi.json: API schema template

FEATURES:
✅ All-in-One Executable: Everything integrated into one file
✅ Automatic Browser Installation: Handles Playwright setup
✅ Automatic GPT Setup: No manual configuration needed
✅ Smart URL Detection: Automatically configures ngrok tunnel
✅ Professional Templates: Uses complete instructions and API schema
✅ One-Click Launch: Just run the executable
✅ Error Recovery: Handles failures gracefully

USAGE:
1. Run linkedin-network-builder.exe --install-browsers (first time only)
2. Run linkedin-network-builder.exe
3. Wait for ngrok tunnel to start
4. Choose whether to set up ChatGPT integration
5. Use your LinkedIn Network Builder!

API ENDPOINTS:
- /browse_company_people - Get connections at a company
- /find_mutual_connections - Find mutual connections with someone
- /find_people_by_role - Find people with specific roles

TROUBLESHOOTING:
- Run as Administrator if you have permission issues
- Ensure you have internet access for ngrok and GPT setup
- Check console output for detailed status messages
- If browsers fail to install, try running --install-browsers separately

Enjoy your LinkedIn Network Builder!
